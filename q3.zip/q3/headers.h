#ifndef _HEADERS_H_
#define _HEADERS_H_

#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <netdb.h>
#define PORT 12000
#define SA struct sockaddr
#define MAX_BUF_SIZE 10000
#include <bits/stdc++.h>
#include <pthread.h>
#define DICTIONARY_SIZE 10000

#endif
